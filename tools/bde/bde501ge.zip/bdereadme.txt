***********************************************************
            Hinweise zu BDE- und SQL Links
***********************************************************

Diese Datei enth�lt neueste Informationen zur Borland Database 
Engine (BDE) und zu SQL Links f�r Windows sowie �berarbeitete
Passagen f�r die Dokumentation. Wenn sich die Erl�uterungen in der
Dokumentation f�r BDE bzw. SQL Links von der vorliegenden 
Datei unterscheiden, dann gelten die neuen Informationen in 
dieser Datei.


INHALTSVERZEICHNIS
==================
  1. TIPS F�R DIE VERWENDUNG VON BDE UND SQL LINKS
  2. �NDERUNGEN IM VERHALTEN
  3. WEITERGABE VON BDE UND SQL LINKS
  4. DOKUMENTATION ZU BDE UND SQL LINKS
  5. UPDATES, TECHNISCHE INFOS UND LETZTE NEUIGKEITEN
  6. KONFIGURIEREN DER BDE
  7. AKTUALSIERUNGEN IN DER DOKUMENTATION
  8. BEKANNTE PROBLEME


1. TIPS F�R DIE VERWENDUNG VON BDE UND SQL LINKS
================================================
1.1 SQL Links
-------------
Informationen �ber die Konfiguration und die Herstellung
der Verbindung zu SQL-Servern finden Sie in der Hilfedatei
SQLLNK32.HLP. Diese Datei enth�lt auch das Thema
"Probleme und Hinweise" mit Hinweisen und 
Informationen zur Fehlerbehebung. Die Datei
befindet sich im BDE-Hauptverzeichnis.

Die Verf�gbarkeit von SQL Links h�ngt vom verwendeten
Inprise-Produkt ab. In der Dokumentation zum Inprise-Produkt
k�nnen Sie nachlesen, ob SQL Links verf�gbar ist.

1.2 BDE
-------
Informationen zur Konfiguration der BDE, zur Verwendung von
Aliasnamen und zur Bereitstellung von ODBC-Teibern f�r 
die BDE finden Sie in der Hilfedatei BDEADMIN.HLP. Die 
API-Funktionen der BDE werden in der Hilfedatei BDE32.HLP 
beschrieben. Informationen �ber die Migration von Daten 
zwischen Datenbanken mit dem Dienstprogramm DataPump
enth�lt die Hilfedatei DATAPUMP.HLP. Die Verwendung von
SQL mit lokalen Tabellen (dBASE oder Paradox) wird in der
Hilfedatei LOCALSQL.HLP erl�utert. Alle BDE-Hilfedateien
befinden sich im BDE-Hauptverzeichnis.


2. �NDERUNGEN IM VERHALTEN
==========================
2.1 Erh�hte Ausf�hrungsgeschwindigkeit von DbiModifyRecord
----------------------------------------------------------
DbiModifyRecord generiert f�r unver�nderte Datensatzpuffer
keine UPDATE-Anweisung mehr. Dadurch erh�ht 
sich die Ausf�hrungsgeschwindigkeit.

2.2 InterBase-�nderungen
------------------------
2.2.1 Transaction Isolation Levels & InterBase
----------------------------------------------
Durch Hinzuf�gen von 4096 zur Einstellung DRIVER FLAGS 
in der BDE-Konfiguration k�nnen Sie festlegen, da� der 
SQL Links-Treiber von InterBase Soft Commits verwendet. 
Soft Commits sind eine InterBase-Funktion, die es 
erm�glicht, da� der Treiber beim Eintragen von �nderungen
den Cursor beibeh�lt. Durch Verwendung von Soft Commits
l��t sich die Ausf�hrungsgeschwindigkeit bei der 
Aktualisierung gro�er Datenmengen erh�hen. Wenn 
diese M�glichkeit nicht genutzt wird, mu� die BDE auch 
dann alle Datens�tze neu abrufen, wenn nur ein Datensatz
ge�ndert wurde. Bei Verwendung von Soft Commits wird der
Cursor beibehalten, und es ist kein Abrufen der 
Daten erforderlich. In expliziten Transaktionen, die von
BDE-Client-Anwendungen gestartet werden, kommen keine Soft 
Commits zur Anwendung. Die Soft-Commit-Eigenschaft 
entspricht der Transaktionsoption COMMIT RETAINING
in der InterBase-Dokumentation.

  TREIBER-FLAGS Isolationsstufe  Commit-Typ
  ------------  ---------------  ------------
  0             Read committed   Hard Commit
  512           Repeatable read  Hard Commit
  4096          Read committed   Soft Commit
  4608          Repeatable read  Soft Commit

Das Treiber-Flag 4096 wirkt sich nur auf das implizite 
Transaktionsverhalten aus. Mit der Eigenschaft COMMIT 
RETAINING k�nnen Sie das Standardverhalten von expliziten
Transaktionen beim Eintragen steuern. 

2.2.2 Rollen
------------
InterBase erm�glicht es den Benutzern, sich mit einer 
bestimmten Rolle anzumelden. ROLE NAME
ist ein neuer Konfigurationsparameter der BDE, �ber 
den BDE-Clients einen Rollennamen �bergeben k�nnen.
ROLE NAME kann auch bei der Verwendung einer 
TDatabase-Komponente (Delphi und C++Builder) als 
optionaler Parameter �bergeben werden.

Diese Informationen setzen die Erl�uterung im InterBase 
5.5 Operations Guide au�er Kraft. Dort ist angegeben, da� 
die BDE keine Eigenschaft f�r die Festlegung eines 
Rollennamens besitzt.

2.2.3 Transaktion WAIT
----------------------
Zum gegenw�rtigen Zeitpunkt verwendet der InterBase 
SQL Links-Treiber bei der Aufl�sung von Sperren-
konflikten NOWAIT und gibt beim Auftreten eines 
Ressourcenkonflikts sofort einen Fehler aus. Wenn
der Konfigurationsparameter WAIT ON LOCK angegeben
wird, kann SQL Links f�r InterBase-Transaktionen WAIT 
verwenden. (Sie k�nnen zu diesem Zweck aber auch die 
Datenbankeigenschaft r/w dbWAITONLOCK auf TRUE setzen.)

2.2.4 Explizite Transaktionen
-----------------------------
Der neue BDE-Konfigurationsparameter COMMIT RETAIN
erm�glicht die Verwendung von Soft Commits bei expliziten 
Transaktionen. Dieselbe Wirkung kann auch �ber die neue 
Datenbankeigenschaft dbCOMMITRETAIN erreicht werden. 
Der Parameter bzw. die Eigenschaft wirkt sich nur auf 
explizite Transaktionen aus. Die bereits vorhandenen Flags bleiben 
weiterhin f�r explizite Transaktionen g�ltig.

  COMMIT RETAINING = TRUE    Aufruf von isc_commit_retaining()
  COMMIT RETAINING = FALSE   Aufruf von isc_commit_transaction()

2.3 Y2K und die Parameter FOURDIGITYEAR und YEARBIASED
------------------------------------------------------

Die Beschreibung f�r die Parameter FOURDIGITYEAR und 
YEARBIASED hat sich ge�ndert. Die folgenden Informationen 
ersetzen die Erl�uterungen in der Online-Hilfe der 
BDE-Verwaltung.

FOURDIGITYEAR
  �ber diesen Parameter wird festgelegt, wie die BDE
  die Jahrhundertangabe in einem Datumsausdruck
  behandelt, wenn nur die beiden letzten Ziffern eines
  Jahres angegeben sind. Wenn der Parameter auf FALSE
  gesetzt ist, wird die Jahrhundertangabe automatisch
  hinzugef�gt, ausgehend von ihrer relativen Position in 
  einem bei Null beginnenden Bereich. Wenn das Datum
  zwischen dem 01.01.00 und dem 31.12.49 liegt, wird
  davon ausgegangen, da� es sich um eine Jahresangabe 
  des 21. Jahrhunderts handelt (20.05.22 wird zu 
  20.05.2022). Liegt das Datum zwischen dem 01.01.50 
  und dem 31.12.99, wird als Jahrhundertangabe das 20. Jahr-
  hundert angenommen (12.08.98 wird zu 12.08.1998). 
  Wenn der Parameter den Wert TRUE hat, gibt es keine
  Auswirkungen auf Datumsangaben mit Jahrhundertkennung
  (bei 30.12.1902 wird weiterhin der 30.12.1902 angenommen).
  
  Wenn FOURDIGITYEAR auf den Wert TRUE gesetzt 
  ist, wird die Jahresangabe des Datums als Literal
  angesehen (dem Datum wird nicht automatisch ein
  Jahrhundert hinzugef�gt). So steht die Jahresangabe im 
  Datum 07.12.96 tats�chlich f�r das Jahr 96 (0096).

  FOURDIGITYEAR wirkt sich beispielsweise auf 
  Datumsliterale in SQL-Anweisungen aus.

YEARBIASED
  �ber diesen Parameter legen Sie fest, ob die BDE zu 
  einer zweistelligen Jahresangabe eine Jahrhundertkennung
  hinzuf�gt. Wenn der Parameter z.B. den Wert
  TRUE hat und Sie "21.7.96" eingeben, wird dieser
  Wert von der BDE als "21.7.1996" interpretiert. 
  Hat der Parameter den Wert FALSE, wird das Datum 
  so interpretiert, wie es eingegeben wurde (in diesem
  Fall als "21.07.0096"). Hinsichtlich der Bestimmung des 
  Jahrhunderts gelten dieselben Vorgaben wie f�r den 
  Parameter FOURDIGITYEAR.


3. WEITERGABE VON BDE UND SQL LINKS
===================================
In der Datei BDEDEPLOY.TXT finden Sie detaillierte 
Informationen �ber die Weitergabe von BDE und SQL 
Links zusammen mit Anwendungen. Diese Datei befindet 
sich im BDE-Hauptverzeichnis.


4. DOKUMENTATION ZU BDE UND SQL LINKS
=====================================

Die Dokumentation f�r die Borland Database Engine (BDE)
und SQL LINKS steht ausschlie�lich in Form von Online-
Hilfedateien zur Verf�gung (siehe "1. Tips f�r die Verwendung
von BDE und SQL LINKS"). Wenn sich die Informationen in den 
Online-Hilfedateien von den Erl�uterungen in der vorliegenden 
Readme-Datei unterscheiden, gelten die Informationen in der
Readme-Datei.


5. UPDATES, TECHNISCHE INFOS UND LETZTE NEUIGKEITEN
===================================================
5.1 Die Beschaffung von Updates
-------------------------------
Updates der Borland Database Engine (BDE), SQL Links 
und der dazugeh�rigen Dokumentationen erhalten Sie auf
unterschiedliche Art und Weise. Updates stehen auf 
der Inprise-Website unter folgender Adresse zur Verf�gung: 

  http://www.inprise.com/devsupport/bde/

Auf dieser Website finden Sie au�erdem Tips, Links
zu technischen Informationsbl�ttern, Beispiele und
weitere hilfreiche Informationen.

5.2 Der neue MS-SQL Server 7-Treiber 
-------------------------------------
Der SQL Links-Treiber f�r Microsoft SQL Server unterst�tzt
jetzt neben der Version 6.5 auf die Version 7. (SQL Links 
steht nicht in allen Editionen der Inprise-Programmiertools
zur Verf�gung.)

SQL Links verwendet DBLIB, die native API f�r 
MS-SQL Server. DBLIB implementiert nur den 
Funktionsumfang von MS-SQL Server 6.5. Das bedeutet, 
da� neue Typen von MS-SQL Server 7, wie GUID, 
Unicode und CHAR-Spalten, die mehr als 255 Zeichen
umfassen, nicht unterst�tzt werden. Microsoft wird DBLIB
nicht um eine Unterst�tzung dieser neuen Typen erweitern, so
da� der SQL Links-Treiber diese neuen MS-SQL Server 7-Typen 
nicht verarbeiten kann. 

Microsoft und Inprise raten dringend, Client-Software einzusetzen,
die f�r den verwendeten MS-SQL Server geeignet ist. Folglich 
k�nnen Sie 6.x-Client-Software nur mit 6.x-Server-Software und 
Client-Software der Version 7 nur mit Server-Software
der Version 7 verwenden. 


6. KONFIGURIEREN DER BDE
========================
Die Borland Database Engine (BDE) wird mit dem Dienstprogramm
BDE-Verwaltung ausgeliefert. Dieses Programm wird im
BDE-Hauptverzeichnis installiert. Sie k�nnen damit folgende 
Aufgaben ausf�hren: Konfigurieren der BDE, Hinzuf�gen,
L�schen und �ndern von BDE-Aliasnamen, Konfigurieren 
von Datenbanktreibern und Herstellen von Verbindungen zu
installierten ODBC-Treibern (diese letzte Funktion ist nicht bei
allen Programmiertools verf�gbar, mit denen die BDE installiert wird). 

Bei einigen Programmiertools (in denen die BDE enthalten ist) ist
es m�glich, SQL Links in einem anderen Verzeichnis als die BDE 
zu installieren. Von diesem Vorgehen wird aber dringend 
abgeraten (SQL Links steht nicht bei allen Versionen der 
Programmiertools zur Verf�gung.)


7. AKTUALSIERUNGEN IN DER DOKUMENTATION
=======================================
7.1 Neue REF-Feldeigenschaft von Oracle 8: curREFINSERTTABLENAME
----------------------------------------------------------------
Wenn beim Einf�gen von Datens�tzen ein Cursor mit 
DbiOpenRef() ge�ffnet ist, mu� der BDE der Name der
Standalone-Tabelle bekannt sein, in die die Datens�tze 
eingef�gt werden sollen. Wenn diese Eigenschaft nicht
festgelegt wurde, tritt ein Fehler auf. 

  DbiSetProp( hCur, curREFINSERTTABLENAME, (UINT32)
    <pszStandAloneTableName> );

7.2 Neue REF-Feldeigenschaft von Oracle 8: curGETREF
----------------------------------------------------
Nach dem Einf�gen eines Datensatzes k�nnen Sie die
Objekt-ID f�r den neuen Datensatz ermitteln, indem Sie 
Speicherplatz (iLen des REF-Feldes der �bergeordneten 
Komponente) zuweisen und an DbiGetProp() �bergeben.

  DbiGetProp( hCur, curGETREF, pOBJECTID, refSize,
    &iObjectLen );


8. BEKANNTE PROBLEME
====================
8.1 Oracle 8
------------
Mit dem neuesten Oracle 8.0.4-Client mu� der Oracle 8-Treiber 
(SQLORA8.DLL) verwendet werden. Oracle 8.0.3-Client 
weist folgende bekannte Probleme auf: 

Die BDE unterst�tzt keine Referenz auf Objektelemente 
in aktualisierbaren Abfragen.

Die BDE unterst�tzt keine Indizes in verschachtelten
Tabellen.

COLLECTION- (NESTED TABLE/VARRAY) und REFERENCE-Zugriff:
Wenn Daten aus NESTED TABLE-Daten abgerufen oder Bewegungen
in NESTED TABLE-Daten ausgef�hrt werden, geht Speicherplatz 
verloren. Hierbei handelt es sich um das Oracle-Problem #593042. 
Zur L�sung dieses Problems wenden Sie sich an Oracle 
(OCI 8.0.4.2-Patch).

Speicherleck bei der h�ufigen Wiederholung einer Abfrage.
Beseitigung: Rufen Sie bei jeder Ausf�hrung der Abfrage DbiQFree() 
und DbiQPrepare() auf. 

8.3 Sybase CT-LIB-Treiber f�r  SQL Links 
-----------------------------------------
Der CT-Lib-Treiber kann mit der Sybase-Version 
10.0.4 EBF7264 und h�her verwendet werden.

8.4 BDE- & CGI-Anwendungen [43890][12552]
-----------------------------------------
Wenn der Umfang von BDE-Initialisierungen zu hoch 
ist (dies h�ngt von den jeweiligen Gegebenheiten ab), 
tritt in CGI-Anwendungen der Fehler "Operation nicht 
ausf�hrbar" auf. Die einzig bekannte L�sung dieses Problems
ist die Verwendung von ISAPI anstelle von CGI.

8.5 DbiBatchMove & dBASE/Paradox nach Sybase [13320]
----------------------------------------------------
DBiBatchMove mit einem Mode-Wert von batCOPY 
schl�gt fehl, wenn Daten aus einer Paradox- oder dBASE-
Tabelle in eine Sybase-Tabelle kopiert werden. Es wird 
der Fehler "Allgemeiner SQL-Fehler" gemeldet.

8.6 SQL Explorer & Sybase 11.5 und h�her [43494]
------------------------------------------------
Trifft auf Enterprise Editionen von Programmiertools zu, die
die BDE nutzen. Bearbeiten Sie die Datei DBX.DBI mit einem 
Texteditor (z.B. NotePad). DBX.DBI befindet sich im 
Verzeichnis, in dem SQL Explorer installiert wurde. �ndern 
Sie die folgende Zeile:

  SYBASE:IdentityRE=SQL Server/([0-9]+)\.
  
Die Zeile mu� folgenderma�en aussehen:

  SYBASE:IdentityRE=[SQL Server][Adaptive Server Enterprise]/([0-9]+)\.

8.7 DB/2 und Dezimaltrennzeichen
--------------------------------
Bestimmte Versionen der DB/2-Client-Bibliothek 
liefern Dezimaltrennzeichen zur�ck, die in den 
regionalen Windows-Einstellungen definiert sind. 
Wenn in diesen Einstellungen als Wert ein anderes 
Dezimaltrennzeichen als der Punkt (".") festgelegt und 
die BDE-Konfigurationseinstellung ENABLE BCD auf
TRUE gesetzt ist, kann es bei der Bearbeitung der Datentypen 
NUMERIC und DECIMAL zu Fehlern kommen. Die IBM-Bibliothek
sollte unabh�ngig von den regionalen Einstellungen immer einen 
Punkt als Dezimaltrennzeichen zur�ckliefern.


======================================================
Wenn nicht anders angegeben, liegt das Urheberrecht an
den Materialien in dieser Version bei Inprise.
Copyright 1983-1999 Inprise Corporation.
======================================================

